﻿namespace WindowsFormsApplication1
{
    partial class DMS
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.Pd = new System.Windows.Forms.TabPage();
            this.Bupd = new System.Windows.Forms.Button();
            this.CBdob12 = new System.Windows.Forms.ComboBox();
            this.CBdob11 = new System.Windows.Forms.ComboBox();
            this.CBdob10 = new System.Windows.Forms.ComboBox();
            this.CBdob9 = new System.Windows.Forms.ComboBox();
            this.CBdob8 = new System.Windows.Forms.ComboBox();
            this.CBdob4 = new System.Windows.Forms.ComboBox();
            this.CBdob7 = new System.Windows.Forms.ComboBox();
            this.CBdob3 = new System.Windows.Forms.ComboBox();
            this.CBdob6 = new System.Windows.Forms.ComboBox();
            this.CBdob2 = new System.Windows.Forms.ComboBox();
            this.CBdob5 = new System.Windows.Forms.ComboBox();
            this.CBdob1 = new System.Windows.Forms.ComboBox();
            this.Bdob = new System.Windows.Forms.Button();
            this.Pdel = new System.Windows.Forms.TabPage();
            this.CBdel = new System.Windows.Forms.ComboBox();
            this.Del = new System.Windows.Forms.Button();
            this.box = new System.Windows.Forms.TabControl();
            this.EditServerSettings = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DataBaseName = new System.Windows.Forms.TextBox();
            this.ServarName = new System.Windows.Forms.TextBox();
            this.EditConnStr = new System.Windows.Forms.Button();
            this.ToUsers = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.Pd.SuspendLayout();
            this.Pdel.SuspendLayout();
            this.box.SuspendLayout();
            this.EditServerSettings.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToDeleteRows = false;
            this.dgv1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dgv1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnKeystroke;
            this.dgv1.Location = new System.Drawing.Point(0, 0);
            this.dgv1.Margin = new System.Windows.Forms.Padding(0);
            this.dgv1.Name = "dgv1";
            this.dgv1.ReadOnly = true;
            this.dgv1.Size = new System.Drawing.Size(1192, 274);
            this.dgv1.TabIndex = 5;
            this.dgv1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(407, 417);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 17);
            this.label1.TabIndex = 8;
            // 
            // Pd
            // 
            this.Pd.Controls.Add(this.Bupd);
            this.Pd.Controls.Add(this.CBdob12);
            this.Pd.Controls.Add(this.CBdob11);
            this.Pd.Controls.Add(this.CBdob10);
            this.Pd.Controls.Add(this.CBdob9);
            this.Pd.Controls.Add(this.CBdob8);
            this.Pd.Controls.Add(this.CBdob4);
            this.Pd.Controls.Add(this.CBdob7);
            this.Pd.Controls.Add(this.CBdob3);
            this.Pd.Controls.Add(this.CBdob6);
            this.Pd.Controls.Add(this.CBdob2);
            this.Pd.Controls.Add(this.CBdob5);
            this.Pd.Controls.Add(this.CBdob1);
            this.Pd.Controls.Add(this.Bdob);
            this.Pd.Location = new System.Drawing.Point(4, 25);
            this.Pd.Margin = new System.Windows.Forms.Padding(4);
            this.Pd.Name = "Pd";
            this.Pd.Padding = new System.Windows.Forms.Padding(4);
            this.Pd.Size = new System.Drawing.Size(1067, 131);
            this.Pd.TabIndex = 2;
            this.Pd.Text = "Добавление";
            this.Pd.UseVisualStyleBackColor = true;
            // 
            // Bupd
            // 
            this.Bupd.Location = new System.Drawing.Point(852, 48);
            this.Bupd.Margin = new System.Windows.Forms.Padding(4);
            this.Bupd.Name = "Bupd";
            this.Bupd.Size = new System.Drawing.Size(204, 31);
            this.Bupd.TabIndex = 31;
            this.Bupd.Text = "Редактировать";
            this.Bupd.UseVisualStyleBackColor = true;
            this.Bupd.Click += new System.EventHandler(this.Bupd_Click);
            // 
            // CBdob12
            // 
            this.CBdob12.FormattingEnabled = true;
            this.CBdob12.Location = new System.Drawing.Point(649, 85);
            this.CBdob12.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob12.Name = "CBdob12";
            this.CBdob12.Size = new System.Drawing.Size(195, 24);
            this.CBdob12.TabIndex = 30;
            // 
            // CBdob11
            // 
            this.CBdob11.FormattingEnabled = true;
            this.CBdob11.Location = new System.Drawing.Point(447, 85);
            this.CBdob11.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob11.Name = "CBdob11";
            this.CBdob11.Size = new System.Drawing.Size(195, 24);
            this.CBdob11.TabIndex = 29;
            // 
            // CBdob10
            // 
            this.CBdob10.FormattingEnabled = true;
            this.CBdob10.Location = new System.Drawing.Point(243, 85);
            this.CBdob10.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob10.Name = "CBdob10";
            this.CBdob10.Size = new System.Drawing.Size(195, 24);
            this.CBdob10.TabIndex = 28;
            // 
            // CBdob9
            // 
            this.CBdob9.FormattingEnabled = true;
            this.CBdob9.Location = new System.Drawing.Point(39, 85);
            this.CBdob9.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob9.Name = "CBdob9";
            this.CBdob9.Size = new System.Drawing.Size(195, 24);
            this.CBdob9.TabIndex = 27;
            // 
            // CBdob8
            // 
            this.CBdob8.FormattingEnabled = true;
            this.CBdob8.Location = new System.Drawing.Point(649, 52);
            this.CBdob8.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob8.Name = "CBdob8";
            this.CBdob8.Size = new System.Drawing.Size(195, 24);
            this.CBdob8.TabIndex = 26;
            // 
            // CBdob4
            // 
            this.CBdob4.FormattingEnabled = true;
            this.CBdob4.Location = new System.Drawing.Point(649, 20);
            this.CBdob4.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob4.Name = "CBdob4";
            this.CBdob4.Size = new System.Drawing.Size(195, 24);
            this.CBdob4.TabIndex = 25;
            // 
            // CBdob7
            // 
            this.CBdob7.FormattingEnabled = true;
            this.CBdob7.Location = new System.Drawing.Point(445, 52);
            this.CBdob7.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob7.Name = "CBdob7";
            this.CBdob7.Size = new System.Drawing.Size(195, 24);
            this.CBdob7.TabIndex = 24;
            // 
            // CBdob3
            // 
            this.CBdob3.FormattingEnabled = true;
            this.CBdob3.Location = new System.Drawing.Point(445, 20);
            this.CBdob3.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob3.Name = "CBdob3";
            this.CBdob3.Size = new System.Drawing.Size(195, 24);
            this.CBdob3.TabIndex = 23;
            // 
            // CBdob6
            // 
            this.CBdob6.FormattingEnabled = true;
            this.CBdob6.Location = new System.Drawing.Point(243, 52);
            this.CBdob6.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob6.Name = "CBdob6";
            this.CBdob6.Size = new System.Drawing.Size(195, 24);
            this.CBdob6.TabIndex = 22;
            // 
            // CBdob2
            // 
            this.CBdob2.FormattingEnabled = true;
            this.CBdob2.Location = new System.Drawing.Point(243, 20);
            this.CBdob2.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob2.Name = "CBdob2";
            this.CBdob2.Size = new System.Drawing.Size(195, 24);
            this.CBdob2.TabIndex = 21;
            // 
            // CBdob5
            // 
            this.CBdob5.FormattingEnabled = true;
            this.CBdob5.Location = new System.Drawing.Point(39, 52);
            this.CBdob5.Margin = new System.Windows.Forms.Padding(4);
            this.CBdob5.Name = "CBdob5";
            this.CBdob5.Size = new System.Drawing.Size(195, 24);
            this.CBdob5.TabIndex = 20;
            // 
            // CBdob1
            // 
            this.CBdob1.AllowDrop = true;
            this.CBdob1.Location = new System.Drawing.Point(39, 20);
            this.CBdob1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CBdob1.Name = "CBdob1";
            this.CBdob1.Size = new System.Drawing.Size(195, 24);
            this.CBdob1.Sorted = true;
            this.CBdob1.TabIndex = 19;
            // 
            // Bdob
            // 
            this.Bdob.Location = new System.Drawing.Point(852, 80);
            this.Bdob.Margin = new System.Windows.Forms.Padding(4);
            this.Bdob.Name = "Bdob";
            this.Bdob.Size = new System.Drawing.Size(204, 31);
            this.Bdob.TabIndex = 4;
            this.Bdob.Text = "Добавить";
            this.Bdob.UseVisualStyleBackColor = true;
            this.Bdob.Click += new System.EventHandler(this.Bdob_Click);
            // 
            // Pdel
            // 
            this.Pdel.Controls.Add(this.CBdel);
            this.Pdel.Controls.Add(this.Del);
            this.Pdel.Location = new System.Drawing.Point(4, 25);
            this.Pdel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Pdel.Name = "Pdel";
            this.Pdel.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Pdel.Size = new System.Drawing.Size(1067, 131);
            this.Pdel.TabIndex = 1;
            this.Pdel.Text = "Удаление";
            this.Pdel.UseVisualStyleBackColor = true;
            // 
            // CBdel
            // 
            this.CBdel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBdel.FormattingEnabled = true;
            this.CBdel.Location = new System.Drawing.Point(337, 62);
            this.CBdel.Margin = new System.Windows.Forms.Padding(4);
            this.CBdel.Name = "CBdel";
            this.CBdel.Size = new System.Drawing.Size(199, 24);
            this.CBdel.TabIndex = 0;
            // 
            // Del
            // 
            this.Del.Location = new System.Drawing.Point(603, 58);
            this.Del.Margin = new System.Windows.Forms.Padding(4);
            this.Del.Name = "Del";
            this.Del.Size = new System.Drawing.Size(200, 31);
            this.Del.TabIndex = 1;
            this.Del.Text = "Удалить";
            this.Del.UseVisualStyleBackColor = true;
            this.Del.Click += new System.EventHandler(this.Del_Click);
            // 
            // box
            // 
            this.box.Controls.Add(this.Pdel);
            this.box.Controls.Add(this.Pd);
            this.box.Controls.Add(this.EditServerSettings);
            this.box.Location = new System.Drawing.Point(15, 288);
            this.box.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.box.Name = "box";
            this.box.SelectedIndex = 0;
            this.box.Size = new System.Drawing.Size(1075, 160);
            this.box.TabIndex = 5;
            // 
            // EditServerSettings
            // 
            this.EditServerSettings.Controls.Add(this.label3);
            this.EditServerSettings.Controls.Add(this.label2);
            this.EditServerSettings.Controls.Add(this.DataBaseName);
            this.EditServerSettings.Controls.Add(this.ServarName);
            this.EditServerSettings.Controls.Add(this.EditConnStr);
            this.EditServerSettings.Location = new System.Drawing.Point(4, 25);
            this.EditServerSettings.Name = "EditServerSettings";
            this.EditServerSettings.Padding = new System.Windows.Forms.Padding(3);
            this.EditServerSettings.Size = new System.Drawing.Size(1067, 131);
            this.EditServerSettings.TabIndex = 3;
            this.EditServerSettings.Text = "Открыть БД";
            this.EditServerSettings.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(131, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Имя базы данных";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(134, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Имя сервера";
            // 
            // DataBaseName
            // 
            this.DataBaseName.Location = new System.Drawing.Point(134, 74);
            this.DataBaseName.Name = "DataBaseName";
            this.DataBaseName.Size = new System.Drawing.Size(100, 22);
            this.DataBaseName.TabIndex = 2;
            this.DataBaseName.Text = "KatTV";
            // 
            // ServarName
            // 
            this.ServarName.Location = new System.Drawing.Point(134, 28);
            this.ServarName.Name = "ServarName";
            this.ServarName.Size = new System.Drawing.Size(100, 22);
            this.ServarName.TabIndex = 1;
            this.ServarName.Text = "KOLOVRAT";
            // 
            // EditConnStr
            // 
            this.EditConnStr.Location = new System.Drawing.Point(303, 73);
            this.EditConnStr.Name = "EditConnStr";
            this.EditConnStr.Size = new System.Drawing.Size(85, 23);
            this.EditConnStr.TabIndex = 0;
            this.EditConnStr.Text = "Открыть";
            this.EditConnStr.UseVisualStyleBackColor = true;
            this.EditConnStr.Click += new System.EventHandler(this.EditConnStr_Click);
            // 
            // ToUsers
            // 
            this.ToUsers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ToUsers.FormattingEnabled = true;
            this.ToUsers.Location = new System.Drawing.Point(1097, 315);
            this.ToUsers.Margin = new System.Windows.Forms.Padding(4);
            this.ToUsers.Name = "ToUsers";
            this.ToUsers.Size = new System.Drawing.Size(95, 24);
            this.ToUsers.TabIndex = 9;
            this.ToUsers.SelectedValueChanged += new System.EventHandler(this.ToUsers_SelectedValueChanged);
            // 
            // DMS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 439);
            this.Controls.Add(this.ToUsers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.box);
            this.Controls.Add(this.dgv1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximumSize = new System.Drawing.Size(1218, 484);
            this.MinimumSize = new System.Drawing.Size(1218, 484);
            this.Name = "DMS";
            this.Text = "Редактирование базы данных";
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.Pd.ResumeLayout(false);
            this.Pdel.ResumeLayout(false);
            this.box.ResumeLayout(false);
            this.EditServerSettings.ResumeLayout(false);
            this.EditServerSettings.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage Pd;
        private System.Windows.Forms.Button Bupd;
        private System.Windows.Forms.ComboBox CBdob12;
        private System.Windows.Forms.ComboBox CBdob11;
        private System.Windows.Forms.ComboBox CBdob10;
        private System.Windows.Forms.ComboBox CBdob9;
        private System.Windows.Forms.ComboBox CBdob8;
        private System.Windows.Forms.ComboBox CBdob4;
        private System.Windows.Forms.ComboBox CBdob7;
        private System.Windows.Forms.ComboBox CBdob3;
        private System.Windows.Forms.ComboBox CBdob6;
        private System.Windows.Forms.ComboBox CBdob2;
        private System.Windows.Forms.ComboBox CBdob5;
        protected System.Windows.Forms.ComboBox CBdob1;
        private System.Windows.Forms.Button Bdob;
        private System.Windows.Forms.TabPage Pdel;
        private System.Windows.Forms.ComboBox CBdel;
        private System.Windows.Forms.Button Del;
        private System.Windows.Forms.TabControl box;
        private System.Windows.Forms.ComboBox ToUsers;
        private System.Windows.Forms.TabPage EditServerSettings;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox DataBaseName;
        private System.Windows.Forms.TextBox ServarName;
        private System.Windows.Forms.Button EditConnStr;
    }
}

